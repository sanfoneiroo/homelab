
#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Execute com sudo: sudo $0"
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive

apt-get update
apt-get install -y \
    net-tools \
    tcpdump \
    curl \
    lynx \
    iproute2 \
    ca-certificates

echo
echo "Ferramentas de rede instaladas."
