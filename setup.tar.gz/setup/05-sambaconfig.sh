
#!/usr/bin/env bash
set -euo pipefail

# Configurações
USUARIO="servidor"
GRUPO="servidor"
SHARE_DIR="/home/servidor"
CONFIG="/etc/samba/smb.conf"

# Verifica privilégios
if [[ $EUID -ne 0 ]]; then
    echo "Execute com sudo: sudo $0"
    exit 1
fi

echo "=== Instalando Samba ==="
apt-get update
apt-get install -y samba

echo
echo "=== Criando grupo e usuário ==="

if ! getent group "$GRUPO" >/dev/null; then
    groupadd "$GRUPO"
fi

if ! id "$USUARIO" >/dev/null 2>&1; then
    useradd -M -g "$GRUPO" -s /usr/sbin/nologin "$USUARIO"
else
    usermod -g "$GRUPO" -s /usr/sbin/nologin "$USUARIO"
fi

echo
echo "=== Definindo senha do Samba ==="
echo "Cadastre a senha que será usada pelos clientes da rede."
smbpasswd -a "$USUARIO"

echo
echo "=== Configurando permissões do diretório ==="

install -d -o "$USUARIO" -g "$GRUPO" -m 2775 "$SHARE_DIR"
chown -R "$USUARIO:$GRUPO" "$SHARE_DIR"
chmod -R 2775 "$SHARE_DIR"

echo
echo "=== Fazendo backup da configuração ==="

if [[ -f "$CONFIG" ]]; then
    BACKUP="${CONFIG}.bak.$(date +%Y%m%d-%H%M%S)"
    cp -a "$CONFIG" "$BACKUP"
    echo "Backup: $BACKUP"
fi

echo
echo "=== Configurando compartilhamento ==="

cat > "$CONFIG" <<'EOF'
[global]
    workgroup = GRUPO
    server string = %h server (Samba)
    security = user
    map to guest = Bad User
    guest account = nobody
    invalid users = root
    passdb backend = tdbsam
    dns proxy = no

    log file = /var/log/samba/log.%m
    max log size = 1000
    syslog = 0

[Servidor]
    comment = Servidor de Arquivos
    path = /home/servidor
    browseable = yes
    read only = no
    guest ok = no
    valid users = servidor
    force group = servidor
    create mask = 0664
    directory mask = 2775
EOF

echo
echo "=== Validando configuração ==="
testparm -s "$CONFIG"

echo
echo "=== Reiniciando Samba ==="
systemctl enable --now smbd
systemctl restart smbd

echo
echo "=== Resultado ==="
systemctl is-active smbd
echo "Usuário de rede: $USUARIO"
echo "Diretório: $SHARE_DIR"
echo 'Compartilhamento: \\IP_DA_VM\Servidor'
echo "Permissão: leitura e escrita autenticada"
