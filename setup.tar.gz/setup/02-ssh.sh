
#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Execute com sudo: sudo $0"
    exit 1
fi

apt-get update
apt-get install -y openssh-server

systemctl enable --now ssh

echo
echo "=== Estado do SSH ==="
systemctl status ssh --no-pager

echo
echo "=== Endereços disponíveis ==="
hostname -I
