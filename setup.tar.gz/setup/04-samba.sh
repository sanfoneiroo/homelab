
#!/usr/bin/env bash
set -euo pipefail

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
    echo "Execute com sudo: sudo $0"
    exit 1
fi

CONFIG="/etc/samba/smb.conf"
SHARE_DIR="/home/servidor"

echo "=== Instalando Samba ==="
apt-get update
apt-get install -y samba

echo
echo "=== Fazendo backup da configuração ==="

if [[ -f "$CONFIG" ]]; then
    BACKUP="${CONFIG}.bak.$(date +%Y%m%d-%H%M%S)"
    cp -a "$CONFIG" "$BACKUP"
    echo "Backup salvo em: $BACKUP"
fi

echo
echo "=== Criando diretório compartilhado ==="

install -d -o root -g root -m 755 "$SHARE_DIR"

echo
echo "=== Configurando Samba ==="

cat > "$CONFIG" <<'EOF'
[global]
    workgroup = GRUPO
    server string = %h server (Samba)
    security = user
    map to guest = Bad User
    guest account = nobody
    invalid users = root
    passdb backend = tdbsam
    dns proxy = no

    log file = /var/log/samba/log.%m
    max log size = 1000
    syslog = 0

[Servidor]
    comment = Servidor de Arquivos
    path = /home/servidor
    browseable = yes
    read only = yes
    guest ok = yes
EOF

echo
echo "=== Validando configuração ==="

testparm -s "$CONFIG"

echo
echo "=== Habilitando serviços ==="

systemctl enable --now smbd
systemctl restart smbd

if systemctl list-unit-files nmbd.service --no-legend \
    | grep -q '^nmbd.service'; then
    systemctl enable --now nmbd
    systemctl restart nmbd
fi

echo
echo "=== Estado do Samba ==="
systemctl --no-pager --full status smbd

echo
echo "=== Endereços da VM ==="
hostname -I

echo
echo "Compartilhamento configurado: $SHARE_DIR"
echo "Nome na rede: \\\\IP_DA_VM\\Servidor"
echo "Acesso configurado como somente leitura."
