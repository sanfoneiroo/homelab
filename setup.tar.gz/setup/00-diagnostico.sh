
#!/usr/bin/env bash
set -u

echo "=== Sistema operacional ==="
cat /etc/os-release

echo
echo "=== Interfaces e endereços IP ==="
ip -br addr

echo
echo "=== Rotas ==="
ip route

echo
echo "=== Gerenciador de rede ==="
for service in networking NetworkManager systemd-networkd; do
    if systemctl is-active --quiet "$service"; then
        echo "$service: ativo"
    elif systemctl is-enabled --quiet "$service" 2>/dev/null; then
        echo "$service: habilitado, mas não ativo"
    else
        echo "$service: não ativo ou não habilitado"
    fi
done

echo
echo "=== SSH ==="
systemctl status ssh --no-pager || true

echo
echo "=== ZeroTier ==="
if command -v zerotier-cli >/dev/null 2>&1; then
    sudo zerotier-cli status
    sudo zerotier-cli listnetworks
else
    echo "ZeroTier não instalado."
fi
