
#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Execute com sudo: sudo $0 NETWORK_ID"
    exit 1
fi

if [[ $# -ne 1 ]]; then
    echo "Uso: sudo $0 NETWORK_ID"
    exit 1
fi

NETWORK_ID="$1"

if [[ ! "$NETWORK_ID" =~ ^[[:xdigit:]]{16}$ ]]; then
    echo "Erro: o NETWORK_ID deve conter 16 caracteres hexadecimais."
    exit 1
fi

if ! command -v zerotier-cli >/dev/null 2>&1; then
    apt-get update
    apt-get install -y curl ca-certificates
    curl -sSf https://install.zerotier.com | bash
fi

systemctl enable --now zerotier-one
zerotier-cli join "$NETWORK_ID"

echo
echo "=== Estado do ZeroTier ==="
zerotier-cli status
zerotier-cli listnetworks
